# A/B pemakaian ulang state identik (alur penuh, max_execution_time=30)

| PGN | langkah | A (s) | B (s) | hasil |
|---|---|---|---|---|
| 20 | run | 22 | 19.2 | IDENTIK |
| 20 | vo | 14.4 | 0.2 | IDENTIK |
| 20 | lng | 24.1 | 8.6 | IDENTIK |
| 20 | dist | 25.3 | 9.1 | IDENTIK |
| 25 | run | 21.9 | 19.2 | IDENTIK |
| 25 | vo | 14 | 0.2 | IDENTIK |
| 25 | lng | 24.2 | 8.2 | IDENTIK |
| 25 | dist | 24.4 | 8.7 | IDENTIK |
| 27 | run | 21.7 | 18.3 | IDENTIK |
| 27 | vo | 14.1 | 0.4 | IDENTIK |
| 27 | lng | 23.3 | 8 | IDENTIK |
| 27 | dist | 22.6 | 7.9 | IDENTIK |

**Seluruh langkah identik: YA**
