# TARGETED TEST GAS SHORTAGE — PGN 20 / PGN 30

Hasil: **9/9**

| id | pemeriksaan | hasil | rincian |
|---|---|---|---|
| T1 | PGN 20: popup Gas Shortage menampilkan angka LNG dan Distillate, tombol aktif setelah validasi | LULUS | popup 12734 ms (awal: "Menghitung opsi yang tervalidasi…"), angka 13756 ms: LNG 9.7385 BBTUD, Distillate 272475.8 l |
| T2 | PGN 20 -> LNG rekomendasi -> rerun final otomatis, hasil final valid | LULUS | 8631 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"add_lng","added":9.7385,"used":0} |
| T3 | PGN 20 -> Distillate rekomendasi -> rerun final otomatis, limit dihormati | LULUS | 9378 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"use_distillate","added":0,"used":270299.2} |
| T4 | PGN 20 -> LNG manual kurang -> sisa ditutup Distillate otomatis | LULUS | LNG 4.8693; 7506 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"mixed_lng_distillate","added":4.8693,"used":135245.6} |
| T5 | PGN 20 -> LNG manual lebih -> memakai kuota LNG user, tanpa Distillate | LULUS | LNG 11.7385; 34375 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"add_lng","added":11.7385,"used":0} |
| T6 | PGN 30 selesai tanpa popup bila tidak ada shortage, hasil final valid | LULUS | modal 75 ms, progres 769 ms, total 26935 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"recommendation","added":0,"used":0} |
| T9 | PGN 20 -> Cancel: popup tertutup, hasil pendahuluan tidak diterbitkan, Export/Publish tetap terkunci, Save Input tetap aktif (V3) | LULUS | popup 339 ms; sesudah Batal: popup=false, gate=true, saveInputAktif=true, exportAktif=false, msg="Dibatalkan. Input dan hasil sebelumnya tidak diubah." |
| T7 | Progress 100% langsung selesai: hasil tampil <= 2 s setelah job DONE, polling berhenti | LULUS | jeda DONE->tampil per skenario (ms): [236,275,245,261,293]; polling sesudah hasil tampil: [0,0,0,0,0] |
| T8 | Tidak ada CMD/proses OS, tidak ada job gagal/menggantung, tidak ada JavaScript error | LULUS | jobs=7 (DONE), gagal=0, menggantung=0, scan=0 temuan, jsErr=0 |

## Runtime (ms)

```json
{
 "pgn25": {
  "modal": 81,
  "firstProgress": 784,
  "popup": 12734,
  "validated": 13756,
  "optionToFinal": 8631,
  "total": 22392
 },
 "pgn30": {
  "modal": 75,
  "firstProgress": 769,
  "total": 26935
 }
}
```
