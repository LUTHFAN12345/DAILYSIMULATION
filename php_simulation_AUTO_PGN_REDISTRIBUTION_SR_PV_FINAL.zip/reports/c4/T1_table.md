### T1

- CP sebelum → sesudah: 90.5991 → 89.9882 USD/MWh; Heat Rate 8638.4 → 8615.85 BTU/kWh
- Temuan C4 tanpa alasan sebelum: 39; sesudah: 0; mode evaluasi: BB_FIXED_AS_CANDIDATE (evaluasi bebas dispatch kandidat sendiri tidak valid (EXPORT,RAMP: Babelan didispatch ulang berbeda); Babelan dikunci seperti kandidat sehingga dispatch kandidat tereproduksi valid)
- Audit merit akhir: PASS · C4 findings 22, status paksa 5, akun MM2100 penuh 0, PASS_WITH_REASON (bukti counterfactual) 17, FAIL 0
- Evaluasi: 123 evaluasi engine 48 row, fase INDEPENDENT_ROWS, pencarian 8.181 s, bukti 3.783 s · 25 row dievaluasi, 162.990 MW digeser, 17 bukti counterfactual (BB_FIXED_AS_CANDIDATE)

| Row | Time | Donor | Receiver (rencana MW) | Legal headroom receiver (MW) | Δ diterapkan (MW) | Δ tambahan diuji (MW) | Langsung | Dengan pendaratan window gas | Gas used (BBTUD) sebelum→sesudah, window | Export (MW) sebelum→sesudah, range | Hasil |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 17 | 08:30 | G5 | G9 9 | G8 23.21, G9 23.21 | 9 / 9 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 18 | 09:00 | G5 | G9 11 | G8 21.78, G9 21.78 | 0 / 11 | 0.5 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8625, [70.84, 70.88] | 30.11→29.92, [30, 155] | PASS_WITH_REASON |
| 19 | 09:30 | G2/G5 | G9 1, G9 11 | G8 18.26, G9 18.26 | 1.9375 / 12 | 0.3594 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8624, [70.84, 70.88] | 30.12→29.98, [30, 155] | PASS_WITH_REASON |
| 20 | 10:00 | G2/G5 | G9 1, G9 11 | G8 18.14, G9 18.14 | 1.9375 / 12 | 0.3594 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8624, [70.84, 70.88] | 30.13→29.99, [30, 155] | PASS_WITH_REASON |
| 21 | 10:30 | G2/G5 | G9 6.32, G8 2.68, G8 3.64 | G8 6.32, G9 6.32 | 10.7432 / 12.64 | 0.3793 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8621, [70.84, 70.88] | 30.09→29.95, [30, 155] | PASS_WITH_REASON |
| 22 | 11:00 | G2 | G9 5.22, G8 4.72 | G8 4.72, G9 5.22 | 9.94 / 9.94 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 23 | 11:30 | G3/G2/G5 | G9 4, G9 5.97, G8 5.03, G8 4.94 | G8 9.97, G9 9.97 | 19.94 / 19.94 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 24 | 12:00 | G5 | G9 11 | G8 13, G9 13.5 | 8.375 / 11 | 0.3282 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8621, [70.84, 70.88] | 30.12→29.99, [30, 155] | PASS_WITH_REASON |
| 26 | 13:00 | G5 | G9 11 | G8 16.61, G9 16.61 | 0 / 11 | 0.5 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8625, [70.84, 70.88] | 30.1→29.91, [30, 155] | PASS_WITH_REASON |
| 27 | 13:30 | G2/G5 | G9 6.16, G8 4.84, G8 1.32 | G8 6.16, G9 6.16 | 12.32 / 12.32 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 28 | 14:00 | G2 | G9 2, G8 2 | G8 2, G9 2 | 4 / 4 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 29 | 14:30 | G2 | G9 2, G8 2 | G8 2, G9 2 | 4 / 4 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 30 | 15:00 | G2 | G9 2, G8 2 | G8 2, G9 2 | 4 / 4 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 31 | 15:30 | G3/G2 | G9 1.5, G9 3.82, G8 4.92 | G8 4.92, G9 5.32 | 10.24 / 10.24 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 32 | 16:00 | G3/G2/G5 | G9 4.5, G9 5.95, G8 5.05, G8 5.4 | G8 10.45, G9 10.45 | 20.9 / 20.9 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 33 | 16:30 | G5 | G9 11 | G8 13, G9 13 | 11 / 11 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 34 | 17:00 | G5 | G9 11 | G8 11.48, G9 11.48 | 1.1563 / 11 | 0.3281 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8625, [70.84, 70.88] | 15.11→14.98, [15, 155] | PASS_WITH_REASON |
| 35 | 17:30 | G5 | G9 9.19, G8 1.81 | G8 8.69, G9 9.19 | 10.3438 / 11 | 0.3281 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.862, [70.84, 70.88] | 15.09→14.96, [15, 155] | PASS_WITH_REASON |
| 36 | 18:00 | G5 | G9 11 | G8 13, G9 13.5 | 9.0313 / 11 | 0.3281 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8621, [70.84, 70.88] | 15.09→14.97, [15, 155] | PASS_WITH_REASON |
| 38 | 19:00 | G5 | G9 2 | G8 5.67, G9 5.67 | 1.25 / 2 | 0.375 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8619, [70.84, 70.88] | 15→14.84, [15, 155] | PASS_WITH_REASON |
| 39 | 19:30 | G5 | G9 7.57, G8 2.93 | G8 7.07, G9 7.57 | 10.5 / 10.5 | — | — | — | — | — | TRANSFER_LEGAL_APPLIED |
| 40 | 20:00 | G5 | G9 1.5 | G8 5.8, G9 6.3 | 0 / 1.5 | 0.5 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8617, [70.84, 70.88] | 15.04→14.83, [15, 155] | PASS_WITH_REASON |
| 42 | 21:00 | G5 | G9 2.49, G8 1.01 | G8 1.99, G9 2.49 | 0.875 / 3.5 | 0.375 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.862, [70.84, 70.88] | 15.12→14.96, [15, 155] | PASS_WITH_REASON |
| 43 | 21:30 | G5 | G9 3.5, G8 1 | G8 3, G9 3.5 | 1 / 4.5 | 0.5 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8619, [70.84, 70.88] | 15.07→14.86, [15, 155] | PASS_WITH_REASON |
| 44 | 22:00 | G5 | G9 2.5 | G8 2.97, G9 2.97 | 0.5 / 2.5 | 0.5 | INVALID:EXPORT | INVALID:EXPORT | 70.8626→70.8618, [70.84, 70.88] | 15.16→14.95, [15, 155] | PASS_WITH_REASON |

