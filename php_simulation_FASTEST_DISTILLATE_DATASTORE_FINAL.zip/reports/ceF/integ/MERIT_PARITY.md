# Paritas merit dispatch 12 state vs checkpoint integrasi (merit PASS)

Referensi: run cold checkpoint integrasi (source merit `a905f10`). Baru: source beku final. Dibandingkan: tanda tangan dispatch fisik 48 row, CP, Heat Rate — untuk cold, tanpa pembantu, dan warm.

| state | ref sig / CP / HR | cold | tanpa pembantu | warm | hasil |
|---|---|---|---|---|---|
| BASE_PGN30 | 1c2e009adeae / 64.6644 / 8386.61 | identik | identik | identik | PASS |
| WB09_3 | fdd9c3c6bb71 / 63.4469 / 8109.13 | identik | identik | identik | PASS |
| WB09 | 4dfea9ac8a43 / 64.3644 / 8319.17 | identik | identik | identik | PASS |
| Q_pep_kp72_1 | e8ff268c979f / 64.631 / 8382.58 | identik | identik | identik | PASS |
| OPS:pgn_pipe=33;mj=spinning_reserve_min:5 | d7c5d4eaf249 / 64.4728 / 8296.78 | identik | identik | identik | PASS |
| OPS:pgn_pipe=30;mj=busflow_min:22 | 1c2e009adeae / 64.6644 / 8386.61 | identik | identik | identik | PASS |
| OPS:pgn_pipe=33;mj=pln_export_priority:{"range":{"min":26,"max":155,"r | 7dfc9e57cbf6 / 64.273 / 8253.06 | identik | identik | identik | PASS |
| OPS:pgn_pipe=33;mj=pln_export_priority:{"range":{"min":20,"max":155,"r | 698009db6c76 / 64.4309 / 8287.94 | identik | identik | identik | PASS |
| OPS:pgn_pipe=30;mj=required_mode:{"g1":{"mode":"continuous"},"g8":{"mo | f2407cc397dc / 64.7788 / 8412.58 | identik | identik | identik | PASS |
| Q_pgn_pipe_4 | 3ab7b223502f / 64.1256 / 8207.16 | identik | identik | identik | PASS |
| Q_pep_1 | c7092c1c03cb / 64.4253 / 8336.79 | identik | identik | identik | PASS |
| ACT_PGN_UP | b80c1651bcac / 64.6801 / 8387.69 | identik | identik | identik | PASS |

12/12 state identik pada ketiga mode.
