# A/B pemakaian ulang state identik (alur penuh, max_execution_time=30)

| PGN | langkah | A (s) | B (s) | hasil |
|---|---|---|---|---|
| 20 | run | 17.8 | 15.2 | IDENTIK |
| 20 | vo | 2.6 | 0.1 | IDENTIK |
| 20 | lng | 10 | 6.2 | IDENTIK |
| 20 | dist | 10.4 | 7.3 | IDENTIK |
| 25 | run | 18.2 | 15.9 | IDENTIK |
| 25 | vo | 2.6 | 0.1 | IDENTIK |
| 25 | lng | 10.4 | 6.4 | IDENTIK |
| 25 | dist | 10.6 | 7.1 | IDENTIK |
| 27 | run | 18 | 17.2 | IDENTIK |
| 27 | vo | 2.8 | 0.3 | IDENTIK |
| 27 | lng | 11 | 6.9 | IDENTIK |
| 27 | dist | 11.5 | 7 | IDENTIK |

**Seluruh langkah identik: YA**
