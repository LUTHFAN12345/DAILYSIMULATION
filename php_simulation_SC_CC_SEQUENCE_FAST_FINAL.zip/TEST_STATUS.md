# TEST_STATUS — runtime hotfix
| Test | Result |
|---|---|
| P0 snapshot plan-1, Fastest UI (helpers 3) | 21.4–26.9 s end-to-end (job 16.4–20.6 s); before 33.7 s on this host and 145.2 s reported. CP 71.1216 / HR 8322.87, G9 03:30, G6 05:00, hard / gate / C1–C4 = 0 / STG / BS PASS, 10 candidates / 1 valid |
| P0 slow host (1 core shared ×3, job ceiling 900 s) | before: 2 pipelines, 43 candidates, CP 71.4265 (G9 02:30 / G6 04:00). After: 1 pipeline, 14 candidates, CP 71.1216, 48 rows identical to the fast host |
| P0 CLI serial | 47.9 → 38.4 s; core simulations 76 → 53; 48 rows bit-identical |
| P1 golden | PASS, CP 79.9049, HR 8239.87, fingerprint `ee03d6e8…` unchanged |
