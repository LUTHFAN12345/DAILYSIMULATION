# TEST_STATUS
| Test | Result |
|---|---|
| Plan-1 snapshot, Linux UI (helpers 3) | 24.0 s, CP 71.1216 / HR 8322.87, fingerprint `3d299c42…` unchanged; diagnostics: 4 processes, max_concurrency 4 = PARALLEL |
| XAMPP Windows | NOT RUN on the build server (no Windows host available). The diagnostics block exists so the next XAMPP run shows the cause |
