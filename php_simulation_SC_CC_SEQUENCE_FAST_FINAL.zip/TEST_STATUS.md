# TEST_STATUS (PHP 7.4, emulasi satu CPU, tanpa helper)

| Test | Hasil |
|---|---|
| P0 snapshot aktual: oracle 47f26e8 vs HOTLOOP_OPT=0 vs =1 | PARITY PASS — 48 row semua kolom, gas, Distillate, STG, C1-C4, proof identik (abaikan metadata waktu) |
| CP / HR | 71,1216 / 8322,87 |
| Fingerprint | 3d299c425542f5ad |
| G9 / G6 start | 03:30 / 05:00 |
| hard / gate / Merit C1-C4 STG | PASS / PASS / PASS |
| Clean final rerun via browser (1 CPU) | 48 row identik dengan oracle |
| P1 golden smoke (T9) | CP 79,9049, HR 8239,87, identik dengan oracle |
| Core simulation | 53 (tidak berubah, seluruhnya material) |

Runtime 1 CPU (host uji terakhir): engine 23,7-25,9 s, UI 27,2 s; pada host uji sebelumnya: awal 48,2 s -> 23,8 s (RTOPT).
Target ideal engine <=20 s / UI <=25 s belum tercapai; batas yang tersisa ada di pass shaper yang bergantung target supplier.
