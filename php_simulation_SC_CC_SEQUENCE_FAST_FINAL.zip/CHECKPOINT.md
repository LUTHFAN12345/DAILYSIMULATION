# CHECKPOINT — php_simulation_SC_CC_SEQUENCE_FAST_FINAL

Source commit bb509a6 (branch claude/gifted-ritchie-q0hfdp). Oracle: 47f26e8.

Isi root: index.php, run.php, worker02.php, worker_functions.php, saved_data_store.php.

Perubahan runtime (server satu CPU), semuanya eksak (cache fungsi murni, tanpa approximation):
- Polling ringan: prelim_progress dan job_poll (job belum selesai) dijawab tanpa memuat engine (PP_LIGHT_POLL=0 mematikan).
- report_planning dibuang di mode=run sebelum hashing/job input/helper/core/proof.
- PP_V1518_RTOPT: cache bahan bakar row konstan + exAt lazy di planForLevel, batas per row di mkFull, meta unit,
  memo calc_stg, potongan pp_rows_signature, prefix pp_fuel_sum_g19, skip-ahead pemindaian FINAL GAS TOP-UP.
- PP_V1518_HOTLOOP_OPT: lookup lazy unit x row (stopped / effective max / fixed load) di loop BB re-maximize, BB up-fill,
  quota top-up dan FINAL GAS TOP-UP; cache bahan bakar per row (gasJRowF).
- Jumlah candidate, supplier attempt, core simulation (53), urutan keputusan dan comparator TIDAK berubah.
- Simulasi final, hard validation, C1-C4/STG proof, CP/HR dan proof binding tetap penuh 48 row.

Profiler runtime sementara (run_prof.php) TIDAK disertakan: profiler dan tombolnya nonaktif.
Saklar rollback: PP_V1518_RTOPT=0, PP_V1518_HOTLOOP_OPT=0, PP_LIGHT_POLL=0.
