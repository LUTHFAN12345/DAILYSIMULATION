# Status uji saat checkpoint

| suite | source | mulai (UTC) | status | PASS/FAIL | log |
|---|---|---|---|---|---|
| Targeted V12 (targeted_v12.sh, 31 bagian) | beku-2 = 7ac6ab8 | 2026-09-30 12:15 | **DIHENTIKAN** 12:57 atas permintaan (bagian 8/31) | 70 / 0 | reports/tgtG/targeted_v12_partial.log |
| Targeted V12 | beku-1 (sebelum 7ac6ab8) | 2026-09-30 | selesai | 315 / 0 | reports/tgtF/targeted_v12.log |
| Full regression V12 (_full_v12.sh) | beku-1 | 2026-09-30 09:1x | selesai | seluruhnya = baseline V11 kecuali T6, T8 (Target Selesai <15 s) FAIL → diperbaiki di 7ac6ab8 | reports/regF/full_regression_v12freeze1.log |
| Full regression | beku-2 | — | belum dijalankan (rantai dihentikan sebelum mulai) | — | — |
| Clean-extract | beku-2 | — | belum dijalankan | — | — |
| Runtime battery 3x | beku-1 | — | selesai | lihat reports/prof_G/PERF.md | reports/prof_G |

- Test terakhir yang selesai (beku-2): "V8: REPRODUCER + GAS GE + UNIT PRIORITY (jalur job)" T9 deterministik — PASS.
- Bagian yang sedang berjalan saat dihentikan: "V8 UI: REPRODUCER Daily_Plan_09_Jul_26_Baru" (tidak selesai).
- Bagian berikutnya yang belum dijalankan: V8 UI PGN30→reproducer, LINT, Simulation Data+Kuota cold, Transition/Warm, Referensi exact penuh, Kuota basis PGN 30, Event berat, Exact penuh BASE_ACT10, POPUP PGN20, Gas Shortage PGN25/PGN20, TL UI (15..max), TL NOVALID, PROV UI, TARGETED12, SAVE UI, V7 UI (slot, kuota x2, forced stop), V11 UI WB09_3, V12 merit dispatch, V12 rantai bahan bakar.
- Verifikasi terarah perbaikan 7ac6ab8 (sebelum freeze): probe TL <15 s lulus tanpa beban (valid pertama ±5,7 s) dan dengan 3 proses beban CPU penuh.
- Background process setelah checkpoint: **tidak ada** (seluruh server PHP, node, dan skrip uji dihentikan).
