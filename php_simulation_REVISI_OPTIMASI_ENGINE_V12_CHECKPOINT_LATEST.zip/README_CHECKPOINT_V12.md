# CHECKPOINT V12 — BELUM FINAL

**Ini CHECKPOINT, BELUM FINAL. ZIP ini tidak boleh digunakan sebagai production final.**
Pekerjaan berikutnya harus dilanjutkan dari checkpoint V12 ini, bukan dari V11.

- Branch aktif: `claude/gifted-ritchie-q0hfdp`
- Commit checkpoint (HEAD, sudah dipush): `be39aaa0348416c8c061925524173b40185fc72c`
- Commit awal percepatan / perbaikan Target Selesai: `7ac6ab8` (source produksi di root ZIP = source 7ac6ab8; commit be39aaa0348416c8c061925524173b40185fc72c hanya menambah harness/laporan)
- V11 FINAL (rollback): `85e1c5d` — salinan source ada di `rollback/V11_FINAL/`. Source V10 tidak tersedia.
- Status working tree saat ZIP dibuat: bersih (tidak ada perubahan, tidak ada file untracked); lihat CHECKPOINT_GIT_STATUS.txt.

## Yang sudah diterapkan di source
- Parallel decommit screening (tugas samping pembantu, look-ahead 3, work stealing pemilik).
- Evaluasi decommit terisolasi (core run terisolasi berkunci input+fingerprint engine, efek samping di-replay).
- Helper side-task (decommit, evaluasi beku, evaluasi tersusun review, tugas pendaratan).
- Perbaikan prioritas helper untuk Target Selesai: pembantu slot 1 tetap pada spekulasi keluarga → kandidat valid pertama kembali ±5,7 detik sejak Run (setara V11 5,8 detik; sebelumnya 10,5 detik).
- UI Target Selesai: output kandidat valid terbaik diambil lebih awal; pembacaan akhir yang lambat tidak lagi menghasilkan NO VALID RESULT. Terverifikasi tetap lulus dengan 3 proses beban CPU penuh (probe `harness/v12/tl_probe.js`).
- Fast fuel rerun dan jalur LNG surplus (pendaratan commitment basis, tanpa full exact family) sudah diterapkan; rantai bahan bakar lulus pada regression beku-1 (LNG lebih 2,59 s, Distillate 3,08 s, LNG rek 3,83 s).
- Audit merit dispatch, hasil LOW_LOAD_FRAGMENTATION, laporan CP (min absolut / pemenang / Heat Rate / band 0,2 %), sertifikat reuse.

## Hasil sementara
- Dispatch, CP, dan Heat Rate V12 identik dengan V11 pada seluruh skenario battery performa yang dibandingkan (reports/prof_G/PERF.md).
- Targeted V12 pada beku-1 (source sebelum 7ac6ab8): 315 PASS / 0 FAIL (reports/tgtF).
- Full regression pada beku-1: seluruh suite sama dengan baseline V11 kecuali T6/T8 Target Selesai < 15 s (2 FAIL) → akar masalah diperbaiki di 7ac6ab8 (reports/regF).
- Targeted V12 pada beku-2 (= 7ac6ab8): DIHENTIKAN atas permintaan, parsial 70 PASS / 0 FAIL (reports/tgtG).

## Belum selesai
- Full regression terbaru (beku-2) belum dijalankan.
- Clean-extract terbaru belum dilakukan.
- Runtime battery tiga kali pada beku-2 belum dijalankan (hanya beku-1, reports/prof_G).
- Acceptance runtime V12 belum seluruhnya terbukti (lihat PENDING_WORK_V12.md).

## Konfigurasi helper side-task (variabel lingkungan)
| variabel | bawaan | arti |
|---|---|---|
| PP_V12_SIDE | aktif (0 = mati) | tugas samping pembantu |
| PP_V12_SIDE_LOOK | 3 | look-ahead tugas decommit |
| PP_V12_NESTED | mati (1 = aktif) | sisipan tugas samping bersarang |
| PP_V12_LAND | mati (1 = aktif) | pendaratan ganda spekulatif V4 |
| PP_V12_FAMHOLD | mati (1 = aktif) | penahanan keluarga |
| PP_V12_SUPFLAT_MIN | 7 | ambang lintasan datar supplier (4 mengubah hasil — jangan) |
| PP_V12_REVIEW_AHEAD | aktif | batch review berikutnya sebagai tugas pendaratan |
| PP_V12_MERIT_GATE | aktif | gate merit hanya bila review V8 berjalan |
| PP_V10_EXACT_FASTREVIEW | mati | opsional; menemukan CP lebih rendah pada beberapa state tetapi lebih lambat |
| PP_V4_HELPERS | 3 | jumlah pembantu (0 = tanpa pembantu; hasil identik) |
| berkas job `v12_tl.flag` | ditulis pada Run Target Selesai | pembantu slot 1 tidak mengambil tugas samping |

## Isi ZIP
- root: run.php, worker02.php, worker_functions.php, index.php (source produksi 7ac6ab8)
- harness/v12: seluruh harness V12 (prof_state.php, fuelchain.sh, merit_check.php, prof_report.py, make_docs_v12.py, targeted/full/clean-extract/build scripts, tests, ops_inputs, kasus merit, tl_probe.js); harness/v11
- reports/: tgtF, tgtG (parsial), regF, prof_G, PERF_A
- rollback/V11_FINAL
- CHECKPOINT_SOURCE_SHA256.txt, CHECKPOINT_GIT_STATUS.txt, CHECKPOINT_TEST_STATUS.md, CHANGED_FILES_VS_V11_FINAL.txt, PENDING_WORK_V12.md, PROGRESS_V12.md, SHA256SUMS.txt
