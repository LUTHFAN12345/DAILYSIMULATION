# Pekerjaan V12 yang belum selesai
1. Targeted V12 lengkap pada source 7ac6ab8 (beku-2), lalu full regression 0 FAIL, clean-extract, targeted dari ZIP hasil ekstrak.
2. Runtime battery 3x pada beku-2 (median/min/maks), bandingkan dengan V11.
3. Target runtime yang belum tercapai (median beku-1, reports/prof_G/PERF.md): kuota dengan commitment tetap < 10 s (Q_pgn_pipe_1 11,1; Q_lng_1 12,3; Q_pgn_pipe_2 15,0; Q_pep_1 12,3; Q_akasia_1 13,3; Q_pgn_pipe_4 10,4); kuota basis Actual < 15 s (QA_lng_1 15,0; QA_pgn_pipe_1 15,0; QA_pgn_pipe_4 18,6); perintah stop G1 < 15 s (F1 21,0; F2 21,8); 2 dari 6 rute slot > 5 s (ACT_FFJ_UP 5,3; ACT_FFM_UP 5,3).
4. Target yang sudah tercapai: rerun bahan bakar < 10 s (termasuk LNG lebih), Gas Shortage tervalidasi < 20 s, exact berat < 40 s, reproducer UI <= 15,5 s.
5. Evaluasi PP_V10_EXACT_FASTREVIEW (CP lebih rendah, tetapi lebih lambat pada beberapa state).
6. Baru setelah seluruh acceptance: ZIP FINAL.
