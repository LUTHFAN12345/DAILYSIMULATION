# UI dua tahap pgn_pipe 30 -> 31

| id | pemeriksaan | hasil | rincian |
|---|---|---|---|
| U1 | run dasar final valid, Save terbuka | LULUS | {"rows":48,"save":false} |
| U2 | VALID PROVISIONAL tampil <= 15 s dengan label, 48 baris | LULUS | t=5910 ms |
| U3 | selama provisional Export/Publish terkunci, Save Input tetap aktif (V3) | LULUS | {"save":false,"gate":true,"xls":true} |
| U4 | tahap 2 selesai: status akhir dinyatakan (FINAL OPTIMAL, exact ditolak release gate, atau rencana valid lebih murah dipertahankan) | LULUS | t=12965 ms msg=FINAL OPTIMAL — optimasi exact memilih rencana yang sama dengan hasil provisional.Done. Perhitungan eksak selesai — Anda tidak perlu menjalankan ulang. · FINAL OPTIMAL — Target waktu Maximum Review / Waktu aktual 12,7 detik / Kandidat diperiksa 25 / Kandidat v |
| U5 | Export hanya terbuka bila FINAL OPTIMAL; Save Input selalu aktif (V3) | LULUS | {"save":false,"xls":false} |
| U6 | tidak ada JavaScript error | LULUS |  |

Hasil: **6/6**
