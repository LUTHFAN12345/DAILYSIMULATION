# A/B pemakaian ulang state identik (alur penuh, max_execution_time=30)

| PGN | langkah | A (s) | B (s) | hasil |
|---|---|---|---|---|
| 20 | run | 18 | 15.5 | IDENTIK |
| 20 | vo | 2.7 | 0.2 | IDENTIK |
| 20 | lng | 10.2 | 6.3 | IDENTIK |
| 20 | dist | 10.5 | 7.1 | IDENTIK |
| 25 | run | 17.4 | 15 | IDENTIK |
| 25 | vo | 2.7 | 0.2 | IDENTIK |
| 25 | lng | 10.3 | 6.5 | IDENTIK |
| 25 | dist | 10.2 | 7 | IDENTIK |
| 27 | run | 17.5 | 15.3 | IDENTIK |
| 27 | vo | 2.8 | 0.3 | IDENTIK |
| 27 | lng | 10.3 | 6.2 | IDENTIK |
| 27 | dist | 10.2 | 6.2 | IDENTIK |

**Seluruh langkah identik: YA**
