# UI: perubahan kuota lewat browser — basis PGN 30 tanpa Actual

JS error: 0

| kasus | perubahan | hasil | valid pertama | FINAL / keputusan | angka rekomendasi | jalur | kandidat (valid) / pruned | core run / simulasi | CP | constraint | rilis |
|---|---|---|---|---|---|---|---|---|---|---|---|
| BASIS | - | FINAL | 2,88 s | 16,25 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (2) / - | 9 / 79 | 64.6658 | hard PASS; Export 48/48; gas 64.5792/64.6; PGN 29.9802/30; residual 0; headroom PASS_WITH_REASON | YA |
| pep:2+pep_kp72:-2.2 | pep 30 → 32, pep_kp72 2.2 → 0 | FINAL | 1,10 s | 12,96 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 7 (4) / - | 2 / 80 | 64.3644 | hard PASS; Export 48/48; gas 64.5228/64.56; PGN 29.9628/30; residual 0; headroom PASS_WITH_REASON | YA |
