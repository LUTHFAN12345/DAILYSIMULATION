# Fastest - Default UI — Change Over OFF (WB09_3)

| id | uji | hasil | bukti |
|---|---|---|---|
| F1 | Fastest - Default di atas < 15 detik, default terpilih, kuning; target biasa putih; Maximum Review merah terang | LULUS | {"value":"fast","labels":["Fastest - Default","< 15 detik","< 25 detik","< 35 detik","< 45 detik","< 55 detik","< 60 detik","Maximum Review"],"values":["fast","15","25","35","45","55","60","max"],"first":{"bg":"rgb(255, 213, 79)","fg":"rgb(93, 58, 0)"},"mid":{"bg":"rgb(255, 255, 255)","fg":"rgb(31, 41, 55)"},"last":{"bg":"rgb(255, 45, 45)","fg":"rgb(255, 255, 255)"}} |
| F2 | tanpa popup progress besar selama run | LULUS | modal_terlihat=false |
| F3 | progres berupa teks biru kecil "Fastest - Default" | LULUS | Fastest - Default — kandidat valid pertama ditemukan (2,0 s); membuktikan merit kandidat itu (counterfactual Unit Priori |
| F4 | selesai dengan hasil fully valid 48 row (FASTEST VALID PLAN atau FINAL OPTIMAL) | LULUS | t=6.96 s rows=48 cp=63.4469 msg=FASTEST VALID PLAN — Target waktu Fastest - Default / Waktu aktual 6,7 detik / Kandidat diperiksa 12 / Kandidat valid 7 / Cost Production 63.4469 USD/MWh fast={"ok":true,"reasons":[],"change_over":null,"stg_proof":{"rows_x_stg":144,"equal_calc":144,"startup_hold":0,"violations":0,"examples":[]},"merit_audit":"PASS","c4":{"findings":46,"fail":0},"llf":"PASS_WITH_OUTCOMES","hard_constraints":"PASS","finalize_s":4.572,"FASTEST_RELEASE_READY":true} |
| F5 | label jujur: FASTEST VALID PLAN menyatakan Global optimum proven NO; FINAL OPTIMAL hanya bila exact selesai | LULUS | FASTEST VALID PLAN — kandidat fully valid pertama (Global optimum proven: NO) |
| F7 | tidak ada JavaScript error | LULUS |  |

6/6 LULUS; waktu selesai 6.96 s.
