# saved_data_store.php — uji penyimpanan

Akar uji: salinan source di direktori sementara, server PHP 7.4 nyata (HTTP), data di <akar>/data.

| id | uji | hasil | bukti |
|---|---|---|---|
| S1 | Save data Actual dan Planning (tombol Save) -> record tersimpan di data/saved/records | LULUS | {"save":{"records":{"written":3,"unchanged":0,"failed":0},"root":"/tmp/claude-0/storetest_9899/data"},"types":{"Actual":1,"Monitoring":1,"Planning":1}} |
| S2 | source engine diubah (fingerprint engine berubah) | LULUS | 88655b9d8032a2da -> cc1a9e30d336e36b |
| S3 | daftar Report tetap ada setelah revisi source (record & checksum sama) | LULUS | {"n":3,"checksum_ok":true} |
| S4 | record lama dibuka: input_payload identik dengan yang disimpan, checksum valid | LULUS | {"checksum_ok":true,"engine_at_save":"run.php:b034b51e56c7 worker02.php:9b21782ef38b worker_functions.php:cc39968b2245"} |
| S5 | record lama dijalankan dengan engine TERBARU (fingerprint hasil = fingerprint source revisi), 48 row | LULUS | {"engine_fingerprint_result":"cc1a9e30d336e36b","engine_now":"cc1a9e30d336e36b","engine_at_save":"run.php:b034b51e56c7 worker02.php:9b21782ef38b worker_functions.php:cc39968b2245","cp":63.4469} |
| S6 | record asli tidak berubah setelah dibuka + dijalankan (tanpa Save eksplisit) | LULUS | 142b71354404b732c8b370024ccc5d1da97db9bd43801eb24df2fda6c2f8ab43 = 142b71354404b732c8b370024ccc5d1da97db9bd43801eb24df2fda6c2f8ab43 |
| S7 | tulis gagal (write/validate/rename) -> Save ditolak, berkas lama utuh & JSON valid, tanpa berkas sementara tersisa | LULUS | {"write":{"result":{"saved":false,"why":"tulis terpotong (313 dari 627 byte)"},"intact":true,"json_valid":true,"tmp_left":0},"validate":{"result":{"saved":false,"why":"validasi baca-ulang berkas sementara gagal"},"intact":true,"json_valid":true,"tmp_left":0},"rename":{"result":{"saved":false,"why":"rename atomik gagal (berkas tujuan dikunci / permission)"},"intact":true,"json_valid":true,"tmp_left":0}} |
| S8 | dua Save bersamaan (2 proses x 25): record berbeda keduanya ada; record sama utuh (satu penulis, tidak tercampur), checksum valid | LULUS | [{"name":"Bersamaan sama","ok":true,"writer":"2","i":24,"pad_ok":true},{"name":"Bersamaan beda 1","ok":true,"writer":"1","i":24,"pad_ok":true},{"name":"Bersamaan beda 2","ok":true,"writer":"2","i":24,"pad_ok":true}] |
| S9 | hapus tanpa konfirmasi ditolak; metadata diperbarui tanpa mengubah checksum isi | LULUS | {"delete":{"ok":false,"error":"KONFIRMASI_DIPERLUKAN: kirim confirm=rec_c2afe46d5e7e8f79fefd9a67"},"meta":{"ok":true,"record_id":"rec_c2afe46d5e7e8f79fefd9a67","meta":{"catatan":"diperiksa"}}} |
| S10 | hapus dengan konfirmasi: record dipindah ke backups/deleted (dapat dipulihkan) | LULUS | {"delete":{"ok":true,"error":null},"backup":["20261004_053432_eeee02_rec_c2afe46d5e7e8f79fefd9a67.json"]} |
| S11 | migrasi skema: record v1 lama dibuka sebagai v2 (input_payload dari snapshot), checksum dihitung | LULUS | {"schema":2,"migrated_from":1} |
| S12 | input_data.json hilang (mis. folder aplikasi diganti) -> dipulihkan dari cermin data/saved/state saat halaman dibuka | LULUS | {"restored":true} |
| S13 | pemeriksaan integritas penyimpanan | LULUS | {"ok":true,"records":6,"checksum_fail":[],"legacy_v1_unverified":["rec_legacyv1"],"state_mirror_ok":true,"root":"/tmp/claude-0/storetest_9899/data","status":"PASS"} |

13/13 LULUS
