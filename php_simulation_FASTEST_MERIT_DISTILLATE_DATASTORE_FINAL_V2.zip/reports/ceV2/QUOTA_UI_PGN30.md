# UI: perubahan kuota lewat browser — basis PGN 30 tanpa Actual

JS error: 0

| kasus | perubahan | hasil | valid pertama | FINAL / keputusan | angka rekomendasi | jalur | kandidat (valid) / pruned | core run / simulasi | CP | constraint | rilis |
|---|---|---|---|---|---|---|---|---|---|---|---|
| BASIS | - | FINAL | 2,96 s | 17,31 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (2) / - | 9 / 79 | 64.6658 | hard PASS; Export 48/48; gas 64.5792/64.6; PGN 29.9802/30; residual 0; headroom PASS_WITH_REASON | YA |
| pgn_pipe:1 | pgn_pipe 30 → 31 | FINAL | 5,73 s | 12,48 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (1) / - | 9 / 47 | 64.545 | hard PASS; Export 48/48; gas 65.5626/65.6; PGN 30.9636/31; residual 0; headroom PASS_WITH_REASON | YA |
| pgn_pipe:-1 | pgn_pipe 30 → 29 | GAS_SHORTAGE_POPUP | - s | 5,92 s | 6,94 s | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (0) / - | 24 / 13 | 64.2315 | hard FAIL; Export 48/48; gas 64.2985/63.6; PGN 29/29; residual 0.7385; headroom PASS_WITH_REASON | tidak |
| pgn_pipe:2 | pgn_pipe 30 → 32 | FINAL | 0,73 s | 16,20 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 7 (4) / - | 3 / 51 | 64.4029 | hard PASS; Export 48/48; gas 66.5685/66.6; PGN 31.9695/32; residual 0; headroom PASS_WITH_REASON | YA |
| pgn_pipe:-2 | pgn_pipe 30 → 28 | GAS_SHORTAGE_POPUP | - s | 6,14 s | 7,16 s | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (0) / - | 24 / 12 | 63.5829 | hard FAIL; Export 48/48; gas 64.2985/62.6; PGN 28/28; residual 1.7385; headroom PASS_WITH_REASON | tidak |
| pgn_pipe:4 | pgn_pipe 30 → 34 | FINAL | 1,53 s | 11,73 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 7 (6) / - | 4 / 57 | 64.1256 | hard PASS; Export 48/48; gas 68.5915/68.6; PGN 33.9925/34; residual 0; headroom PASS_WITH_REASON | YA |
| pgn_pipe:-4 | pgn_pipe 30 → 26 | GAS_SHORTAGE_POPUP | - s | 6,51 s | 7,53 s | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (0) / - | 24 / 11 | 62.2857 | hard FAIL; Export 48/48; gas 64.2985/60.6; PGN 26/26; residual 3.7385; headroom PASS_WITH_REASON | tidak |
| pep:1 | pep 30 → 31 | FINAL | 6,36 s | 14,07 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (2) / - | 9 / 59 | 64.4253 | hard PASS; Export 48/48; gas 65.6648/65.68; PGN 29.9858/30; residual 0; headroom PASS_WITH_REASON | YA |
| pep:-1 | pep 30 → 29 | GAS_SHORTAGE_POPUP | - s | 6,21 s | 7,22 s | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (0) / - | 24 / 12 | 64.2762 | hard FAIL; Export 48/48; gas 64.2985/63.52; PGN 30/30; residual 0.8185; headroom PASS_WITH_REASON | tidak |
| pep:2 | pep 30 → 32 | FINAL | 1,25 s | 12,22 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 7 (4) / - | 2 / 58 | 64.1989 | hard PASS; Export 48/48; gas 66.7218/66.76; PGN 29.9628/30; residual 0; headroom PASS_WITH_REASON | YA |
| pep:-2 | pep 30 → 28 | GAS_SHORTAGE_POPUP | - s | 5,89 s | 6,91 s | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (0) / - | 24 / 12 | 63.6723 | hard FAIL; Export 48/48; gas 64.2985/62.44; PGN 30/30; residual 1.8985; headroom PASS_WITH_REASON | tidak |
| lng:1 | lng 0 → 1 | FINAL | 6,03 s | 12,16 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (1) / - | 9 / 40 | 64.8608 | hard PASS; Export 48/48; gas 65.5626/65.6; PGN 29.9636/30; residual 0; headroom PASS_WITH_REASON | YA |
| lng:-1 | lng 0 → -1 | GAS_SHORTAGE_POPUP | - s | 5,99 s | 7,01 s | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (0) / - | 24 / 12 | 63.9109 | hard FAIL; Export 48/48; gas 64.2985/63.6; PGN 30/30; residual 0.7385; headroom PASS_WITH_REASON | tidak |
| pep_kp72:1 | pep_kp72 2.2 → 3.2 | FINAL | 2,32 s | 20,71 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (2) / - | 18 / 99 | 64.6324 | hard PASS; Export 48/48; gas 65.5793/65.6; PGN 29.9802/30; residual 0; headroom PASS_WITH_REASON | YA |
| pep_kp72:-1 | pep_kp72 2.2 → 1.2 | FINAL | 3,05 s | 15,12 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (2) / - | 9 / 79 | 64.7878 | hard PASS; Export 48/48; gas 63.5779/63.6; PGN 29.9802/30; residual 0; headroom PASS_WITH_REASON | YA |
| akasia:1 | akasia 0 → 1 | FINAL | 5,29 s | 12,55 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (2) / - | 9 / 57 | 64.6661 | hard PASS; Export 48/48; gas 65.6648/65.68; PGN 29.9858/30; residual 0; headroom PASS_WITH_REASON | YA |
| akasia:-1 | akasia 0 → -1 | GAS_SHORTAGE_POPUP | - s | 4,94 s | 5,96 s | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (0) / - | 24 / 12 | 64.0315 | hard FAIL; Export 48/48; gas 64.2985/63.52; PGN 30/30; residual 0.8185; headroom PASS_WITH_REASON | tidak |
| pgn_pipe:-1+pep:2 | pgn_pipe 30 → 29, pep 30 → 32 | FINAL | 5,69 s | 18,20 s | - | EXACT (V9_STATE_TANPA_ACTUAL_EXACT_KANONIK) | 9 (2) / - | 9 / 55 | 64.3188 | hard PASS; Export 48/48; gas 65.7433/65.76; PGN 28.9843/29; residual 0; headroom PASS_WITH_REASON | YA |
