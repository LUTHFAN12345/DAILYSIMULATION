# Path independence V11

Setiap sel: md5 dispatch 48 row (kolom unit + Export, 3 desimal) / Cost Production. SAMA = identik dengan jalur direct.

| state | direct (CLI, cache dingin, tanpa pembantu) | rantai A (CLI) | rantai B (CLI, urutan terbalik) | cache hangat (ulang di akar rantai B) | rantai HTTP (pembantu aktif) | Target Selesai dulu (HTTP, cold) | hasil |
|---|---|---|---|---|---|---|---|
| BASE_PGN30 | 145546290b / 64.6658 | 145546290b / 64.6658 | 145546290b / 64.6658 | - | 145546290b / 64.6658 | - | IDENTIK (4 jalur) |
| WB09 | 550095db8c / 64.3644 | 550095db8c / 64.3644 | 550095db8c / 64.3644 | 550095db8c / 64.3644 | 550095db8c / 64.3644 | 550095db8c / 64.3644 | IDENTIK (6 jalur) |
| WB09_KP72 | 17ec197523 / 64.1989 | 17ec197523 / 64.1989 | 17ec197523 / 64.1989 | - | 17ec197523 / 64.1989 | - | IDENTIK (4 jalur) |
| BASE_ACT10 | 1a551047f3 / 64.6208 | 1a551047f3 / 64.6208 | 1a551047f3 / 64.6208 | - | 1a551047f3 / 64.6208 | - | IDENTIK (4 jalur) |
| ACT_PGN_UP | 4bb1d560af / 64.6801 | 4bb1d560af / 64.6801 | 4bb1d560af / 64.6801 | 4bb1d560af / 64.6801 | 4bb1d560af / 64.6801 | - | IDENTIK (5 jalur) |
| ACT_PGN_DOWN | a97872e330 / 64.5623 | a97872e330 / 64.5623 | a97872e330 / 64.5623 | - | a97872e330 / 64.5623 | - | IDENTIK (4 jalur) |
| ACT_FFJ_UP | 47f1269e35 / 64.6303 | 47f1269e35 / 64.6303 | 47f1269e35 / 64.6303 | - | 47f1269e35 / 64.6303 | 47f1269e35 / 64.6303 | IDENTIK (5 jalur) |
| ACT_FFM_DOWN | ee8adaa626 / 64.6209 | ee8adaa626 / 64.6209 | ee8adaa626 / 64.6209 | - | ee8adaa626 / 64.6209 | - | IDENTIK (4 jalur) |
| KP72_DOWN | 1a551047f3 / 64.6208 | 1a551047f3 / 64.6208 | 1a551047f3 / 64.6208 | - | 1a551047f3 / 64.6208 | - | IDENTIK (4 jalur) |
| ACT_PGN_2SLOT_C | 7e10168655 / 64.698 | 7e10168655 / 64.698 | 7e10168655 / 64.698 | - | 7e10168655 / 64.698 | - | IDENTIK (4 jalur) |
| QA_pgn_pipe_1 | 746aa52b0b / 63.8487 | 746aa52b0b / 63.8487 | 746aa52b0b / 63.8487 | - | 746aa52b0b / 63.8487 | - | IDENTIK (4 jalur) |
| QA_pep_-1 | f038709283 / 65.6235 | f038709283 / 65.6235 | f038709283 / 65.6235 | f038709283 / 65.6235 | f038709283 / 65.6235 | f038709283 / 65.6235 | IDENTIK (6 jalur) |
| WB09_3 | 2b5270f108 / 63.4469 | 2b5270f108 / 63.4469 | 2b5270f108 / 63.4469 | 2b5270f108 / 63.4469 | 2b5270f108 / 63.4469 | 2b5270f108 / 63.4469 | IDENTIK (6 jalur) |

**13/13 state identik di seluruh jalur yang dijalankan** (47 perbandingan terhadap direct).
