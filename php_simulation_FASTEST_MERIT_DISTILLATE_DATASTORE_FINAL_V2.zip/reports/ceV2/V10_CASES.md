# V10 targeted (versi V11, band CP 0,2 %): rute cepat kanonik, sertifikat, screening dua tingkat

PASS 19 / 19

| id | hasil | bukti |
|---|---|---|
| V01 ACT_PGN_UP FINAL rute cepat: 48 row, hard PASS, Export 48/48, residual 0, rilis | PASS | mode INCREMENTAL, pemenang v10_tier2b:winner@-0.16, CP 64.6801 |
| V02 ACT_PGN_UP sertifikat optimalitas cepat lengkap (universe, kunci incumbent, alasan pruning, baris kotor, sidik jari engine/constraint/fuel/priority) | PASS | universe 3be8b1b7a918e39aa0b64646, dibangkitkan 10, dipangkas 0 [], tier2a 7, tier2b 3 |
| V03 ACT_PGN_UP invarian V11: FINAL_CP <= CP kandidat valid termurah x 1,002 (band CP 0,2 %) | PASS | FINAL 64.6801, kandidat valid termurah 64.6587 (11 kandidat valid) |
| V01 KP72_DOWN FINAL rute cepat: 48 row, hard PASS, Export 48/48, residual 0, rilis | PASS | mode INCREMENTAL, pemenang v10_tier2a:v8:SWAP:G5>G2:26-37@0.16, CP 64.6208 |
| V02 KP72_DOWN sertifikat optimalitas cepat lengkap (universe, kunci incumbent, alasan pruning, baris kotor, sidik jari engine/constraint/fuel/priority) | PASS | universe 3be8b1b7a918e39aa0b64646, dibangkitkan 10, dipangkas 0 [], tier2a 7, tier2b 3 |
| V03 KP72_DOWN invarian V11: FINAL_CP <= CP kandidat valid termurah x 1,002 (band CP 0,2 %) | PASS | FINAL 64.6208, kandidat valid termurah 64.6208 (15 kandidat valid) |
| V01 ACT_PGN_2SLOT_C FINAL rute cepat: 48 row, hard PASS, Export 48/48, residual 0, rilis | PASS | mode INCREMENTAL, pemenang v10_tier2a:v8:SWAP:G5>G2:26-37@0.16, CP 64.6980 |
| V02 ACT_PGN_2SLOT_C sertifikat optimalitas cepat lengkap (universe, kunci incumbent, alasan pruning, baris kotor, sidik jari engine/constraint/fuel/priority) | PASS | universe 3be8b1b7a918e39aa0b64646, dibangkitkan 10, dipangkas 0 [], tier2a 7, tier2b 3 |
| V03 ACT_PGN_2SLOT_C invarian V11: FINAL_CP <= CP kandidat valid termurah x 1,002 (band CP 0,2 %) | PASS | FINAL 64.6980, kandidat valid termurah 64.6980 (10 kandidat valid) |
| V01 ACT_FFM_DOWN FINAL rute cepat: 48 row, hard PASS, Export 48/48, residual 0, rilis | PASS | mode INCREMENTAL, pemenang v10_tier2a:v8:SWAP:G5>G2:26-37@0.16, CP 64.6209 |
| V02 ACT_FFM_DOWN sertifikat optimalitas cepat lengkap (universe, kunci incumbent, alasan pruning, baris kotor, sidik jari engine/constraint/fuel/priority) | PASS | universe 3be8b1b7a918e39aa0b64646, dibangkitkan 10, dipangkas 0 [], tier2a 7, tier2b 3 |
| V03 ACT_FFM_DOWN invarian V11: FINAL_CP <= CP kandidat valid termurah x 1,002 (band CP 0,2 %) | PASS | FINAL 64.6209, kandidat valid termurah 64.6209 (15 kandidat valid) |
| V04 pustaka dispatch jangkar dibangun ulang (akar tanpa pustaka) vs dipakai ulang: dispatch 48 row & CP identik | PASS | md5 2bc99608f6 / 2bc99608f6, CP 64.6303 / 64.6303, pustaka dibangun 20.6 s |
| V05 rute cepat tanpa kandidat valid (window total dan supplier tidak dapat dipenuhi bersama) -> jalur kanonik V9 / exact, bukan FINAL palsu | PASS | mode EXACT, alasan rute cepat V10_TIDAK_ADA_KANDIDAT_VALID, status USER_ACTION_REQUIRED |
| V06 Q_pgn_pipe_1 exact: kandidat comparator global yang dicakup node keluarga off:{u} tidak di-full-run; keluarga lengkap; CP V11 <= referensi V9 x 1,002 (band) | PASS | dipangkas ["G5"], cakupan LENGKAP, keluarga 9 node, CP 64.5450 (V9 64.5450), 33.4 s CLI |
| V06 Q_lng_1 exact: kandidat comparator global yang dicakup node keluarga off:{u} tidak di-full-run; keluarga lengkap; CP V11 <= referensi V9 x 1,002 (band) | PASS | dipangkas ["G5"], cakupan LENGKAP, keluarga 9 node, CP 64.8608 (V9 64.8608), 32.8 s CLI |
| V06 WB09 exact: kandidat comparator global yang dicakup node keluarga off:{u} tidak di-full-run; keluarga lengkap; CP V11 <= referensi V9 x 1,002 (band) | PASS | dipangkas [], cakupan -, keluarga 7 node, CP 64.3644 (V9 64.3644), 25.8 s CLI |
| V07 bukti kapasitas Export: seluruh GTG dimatikan -> terbukti infeasible; commitment pemenang jangkar (Export valid 48 row) -> tidak dipangkas (batas atas sah) | PASS | semua off: "Export maks row 1 = -246.6 MW < Range Min 20.0 MW (seluruh unit tersedia pada Effective Max)"; pemenang: null |
| V08 KP72_DOWN lewat rantai (sesudah ACT_PGN_DOWN) vs langsung (akar baru): dispatch & CP identik; state ulang = cache FINAL | PASS | rantai e6bb099b85 CP 64.6208 / langsung e6bb099b85 CP 64.6208; ulang 0.30 s |
