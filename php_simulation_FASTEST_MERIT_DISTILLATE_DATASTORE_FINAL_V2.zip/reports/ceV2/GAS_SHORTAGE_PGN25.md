# TARGETED TEST GAS SHORTAGE — PGN 25 / PGN 30

Hasil: **9/9**

| id | pemeriksaan | hasil | rincian |
|---|---|---|---|
| T1 | PGN 25: popup Gas Shortage menampilkan angka LNG dan Distillate, tombol aktif setelah validasi | LULUS | popup 6394 ms (awal: "Menghitung opsi yang tervalidasi…"), angka 7415 ms: LNG 4.7385 BBTUD, Distillate 132198 l |
| T2 | PGN 25 -> LNG rekomendasi -> rerun final otomatis, hasil final valid | LULUS | 5050 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"add_lng","added":4.7385,"used":0} |
| T3 | PGN 25 -> Distillate rekomendasi -> rerun final otomatis, limit dihormati | LULUS | 3569 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"use_distillate","added":0,"used":131885.5} |
| T4 | PGN 25 -> LNG manual kurang -> sisa ditutup Distillate otomatis | LULUS | LNG 2.3693; 3851 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"mixed_lng_distillate","added":2.3693,"used":66462.1} |
| T5 | PGN 25 -> LNG manual lebih -> memakai kuota LNG user, tanpa Distillate | LULUS | LNG 6.7385; 3516 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"add_lng","added":6.7385,"used":0} |
| T6 | PGN 30 selesai tanpa popup bila tidak ada shortage, hasil final valid | LULUS | modal 77 ms, progres 793 ms, total 13935 ms; {"rows":48,"conv":true,"econ":true,"hard":"PASS","econGate":"PASS","exp":"OK","resid":0,"rel":true,"src":"recommendation","added":0,"used":0} |
| T9 | PGN 25 -> Cancel: popup tertutup, hasil pendahuluan tidak diterbitkan, Export/Publish tetap terkunci, Save Input tetap aktif (V3) | LULUS | popup 327 ms; sesudah Batal: popup=false, gate=true, saveInputAktif=true, exportAktif=false, msg="Dibatalkan. Input dan hasil sebelumnya tidak diubah." |
| T7 | Progress 100% langsung selesai: hasil tampil <= 2 s setelah job DONE, polling berhenti | LULUS | jeda DONE->tampil per skenario (ms): [251,199,236,224,192]; polling sesudah hasil tampil: [0,0,0,0,0] |
| T8 | Tidak ada CMD/proses OS, tidak ada job gagal/menggantung, tidak ada JavaScript error | LULUS | jobs=7 (DONE), gagal=0, menggantung=0, scan=0 temuan, jsErr=0 |

## Runtime (ms)

```json
{
 "pgn25": {
  "modal": 90,
  "firstProgress": 791,
  "popup": 6394,
  "validated": 7415,
  "optionToFinal": 5050,
  "total": 12469
 },
 "pgn30": {
  "modal": 77,
  "firstProgress": 793,
  "total": 13935
 }
}
```
