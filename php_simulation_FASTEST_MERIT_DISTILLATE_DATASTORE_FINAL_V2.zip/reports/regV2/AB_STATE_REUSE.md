# A/B pemakaian ulang state identik (alur penuh, max_execution_time=30)

| PGN | langkah | A (s) | B (s) | hasil |
|---|---|---|---|---|
| 20 | run | 17.7 | 16.3 | IDENTIK |
| 20 | vo | 2.8 | 0.2 | IDENTIK |
| 20 | lng | 11.1 | 6.8 | IDENTIK |
| 20 | dist | 11.2 | 7.2 | IDENTIK |
| 25 | run | 17.6 | 15.8 | IDENTIK |
| 25 | vo | 2.7 | 0.2 | IDENTIK |
| 25 | lng | 10.6 | 6.4 | IDENTIK |
| 25 | dist | 10.9 | 6.8 | IDENTIK |
| 27 | run | 17.2 | 15.4 | IDENTIK |
| 27 | vo | 2.8 | 0.3 | IDENTIK |
| 27 | lng | 10.6 | 6.7 | IDENTIK |
| 27 | dist | 9.7 | 6.1 | IDENTIK |

**Seluruh langkah identik: YA**
